﻿namespace Payroller
{


    partial class PayrollerDataSet
    {
        partial class NominasDataTable
        {
        }

        partial class TransaccionesDataTable
        {
        }
    }
}

namespace Payroller.PayrollerDataSetTableAdapters {
    
    
    public partial class TransaccionesTableAdapter {
    }
}
